import React from 'react';
import './App.css';

class App extends React.Component {
  constructor(props){
    super(props);
    this.state= {
    title : 'Wipro Test App',
    act: 0,
    index:'',
    datas : []
}
}
 
 fSubmit= (e) =>{
     e.preventDefault();
    // console.log('try it');
     let datas = this.state.datas;
     let name = this.refs.name.value;
     let city = this.refs.city.value;
     if(this.state.act === 0){
     let data = {   // add new
        name, city
      }
      datas.push(data);
     }
      this.setState({
        datas:datas,
        act:0
     });
 }

render() {
    let datas = this.state.datas;
    return(
        <div style={{ maxWidth: '100%' }}>
       <h2>{this.state.title}</h2>
       <form ref="myForm" className="myForm"> 
       <input type="text" ref="name" className="FormField__Input" placeholder="your name" />  
       <input type="text" ref="city" className="FormField__Input" placeholder="your city" />
       <button onClick={(e)=>this.fSubmit(e)}  className="FormField__Button">Submit</button>
       </form>
       <table >
         
           {datas.map((data, i) =>
           <tr>
              <td key={i} className="myList">
               {i+1}, {data.name}, {data.city}              
               
              </td>
              </tr>
           )}
       </table>
      </div>
        
    );
}
}

export default App;
